#ifndef _INCLUDE_STRUCTURES_H
#define _INCLUDE_STRUCTURES_H

#include "structures/RBtree.h"

#endif
